from urllib import request
from flask import Flask,request
from flask import render_template
from flask_paginate import get_page_parameter, Pagination
import pymysql
import sqlite3
from pyecharts import options as opts
from pyecharts.globals import ThemeType
from pyecharts.charts import Bar,Funnel
from jinja2 import Markup

app = Flask(__name__)

@app.route('/')
def index():  # put application's code here
    return render_template("index.html")
@app.route('/index')
def home():
    num = []
    conn = pymysql.Connect(
        host='192.168.22.135',
        port=3306,
        user='root',
        password='a',
        db='spark',
        charset='utf8'
    )
    cur = conn.cursor()
    sql = "select count(MealID) as num from avg_Rating"
    data = cur.execute(sql)
    result = cur.fetchall()
    for item in result:
        num.append(item)
    cur.close()
    conn.close()
    return render_template('index.html', num=num)

@app.route('/review')
def movie():
    # datalist = []
    # con = sqlite3.connect("movie250.db")
    # cur = con.cursor()
    # sql = "select * from movie250"
    # data = cur.execute(sql)
    # for item in data :
    #     datalist.append(item)
    # cur.close()
    # con.close()
    datalist = []
    con = pymysql.Connect(
        host='192.168.22.135',
        port=3306,
        user='root',
        password='a',
        db='spark',
        charset='utf8'
    )
    cur = con.cursor()
    sql = "select MealID,Rating,Review,ReviewTime from All_data"
    data = cur.execute(sql)
    result = cur.fetchall()
    for item in result:
        datalist.append(item)
    cur.close()
    con.close()

    # 当前页码，从第一页开始
    page = request.args.get(get_page_parameter(), type=int, default=1)
    # page = int(request.args.get("page", 1))
    # 每页的数量
    per_page = int(request.args.get('per_page', 25))
    pagination = Pagination(page=page, per_page=per_page, total=len(datalist), css_framework='bootstrap4')
    # paginate = data.paginate(page, per_page, error_out=False)
    # 获取当前页的数据
    start = (page - 1) * per_page
    end = start + per_page
    datalist = datalist[start:end]
    # return render_template('review.html',movies = datalist,paginate=paginate)
    return render_template('review.html',movies = datalist,pagination=pagination)
@app.route('/score')
def score():
    conn = pymysql.Connect(
        host='192.168.22.135',
        port=3306,
        user='root',
        password='a',
        db='spark',
        charset='utf8'
    )
    cur = conn.cursor()
    MealID = []
    CumulativeRating = []
    sql = "select * from avg_Rating order by CumulativeRating limit 10 "
    data = cur.execute(sql)
    result = cur.fetchall()
    for item in result:
        MealID.append(str(item[0]))
        CumulativeRating.append(item[1])
    MealName = ["鱼香肉丝","肉末茄子","宫保鸡丁","麻婆豆腐","回锅肉","水煮鱼","麻辣香锅","干煸豆角","蚂蚁上树","东坡肉"]
    # 创建一个空字典用于存储菜品ID与菜品名字的映射
    id_to_name = {}
    # 将菜品ID与菜品名字进行逐对匹配并存储到字典中
    for meal_id, meal_name in zip(MealID, MealName):
        id_to_name[meal_id] = meal_name
    meal_names = list(id_to_name.values())

    MealID1 = []
    CumulativeRating1 = []
    sql1 = "SELECT MealID, SUM(Rating) AS CumulativeRating1 FROM All_data GROUP BY MealID ORDER BY CumulativeRating1 DESC limit 10 "
    data = cur.execute(sql1)
    result = cur.fetchall()
    for item in result:
        MealID1.append(str(item[0]))
        CumulativeRating1.append(item[1])
    MealName1 = ["剁椒鱼头","糖醋里脊","京酱肉丝","宫保虾球","葱爆羊肉","水煮牛肉","蚝油生菜","青椒炒肉","酸辣汤","豆花鱼"]
    # 创建一个空字典用于存储菜品ID与菜品名字的映射
    id_to_name1 = {}
    # 将菜品ID与菜品名字进行逐对匹配并存储到字典中
    for meal_id, meal_name in zip(MealID1, MealName1):
        id_to_name1[meal_id] = meal_name
    meal_names1 = list(id_to_name1.values())

    Rating = []
    num = []
    sql2 = "select * from Rating_count"
    cur.execute(sql2)
    result = cur.fetchall()
    for item in result:
        Rating.append(str(item[0]))
        num.append(item[1])

    cur.close()
    conn.close()
    return render_template('score.html',meal_names = meal_names ,meal_names1 = meal_names1,
                           CumulativeRating=CumulativeRating,CumulativeRating1=CumulativeRating1,
                           Rating=Rating,num=num)

@app.route('/recommend')
def recommend():
    conn = pymysql.Connect(
        host='192.168.22.135',
        port=3306,
        user='root',
        password='a',
        db='spark',
        charset='utf8'
    )
    cur = conn.cursor()
    MealID_Index = []
    Rating = []
    sql = "select MealID_Index,Rating from user_meal where UserID_Index = 1580 order by Rating"
    data = cur.execute(sql)
    result = cur.fetchall()
    for item in result:
        MealID_Index.append(str(item[0]))
        Rating.append(item[1])
    MealName = ["鱼香肉丝", "肉末茄子", "宫保鸡丁", "麻婆豆腐", "回锅肉", "水煮鱼", "麻辣香锅", "干煸豆角", "蚂蚁上树", "东坡肉"]
    # 创建一个空字典用于存储菜品ID与菜品名字的映射
    id_to_name = {}
    # 将菜品ID与菜品名字进行逐对匹配并存储到字典中
    for meal_id, meal_name in zip(MealID_Index, MealName):
        id_to_name[meal_id] = meal_name
    meal_names = list(id_to_name.values())
    # # 创建空列表存储漏斗图数据
    # funnel_data = []
    #
    # # 遍历meal_names和Rating列表
    # for name, rating in zip(meal_names, Rating):
    #     # 创建漏斗图数据对象
    #     data_obj = {
    #         'value': rating,
    #         'name': name
    #     }
    #
    #     # 将漏斗图数据对象添加到列表中
    #     funnel_data.append(data_obj)
    cur.close()
    conn.close()
    # return render_template('recommend.html', funnel_data=funnel_data)
    return render_template('recommend.html', meal_names=meal_names,Rating=Rating)

@app.route('/word')
def word():
    return render_template('word.html')
# @app.route('/team')
# def team():
#     return render_template('team.html')

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
